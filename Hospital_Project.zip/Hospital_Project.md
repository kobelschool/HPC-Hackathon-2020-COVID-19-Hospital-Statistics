```python
pip install google-cloud-storage
```

    Requirement already satisfied: google-cloud-storage in /opt/conda/lib/python3.7/site-packages (1.30.0)
    Requirement already satisfied: google-resumable-media<2.0dev,>=0.6.0 in /opt/conda/lib/python3.7/site-packages (from google-cloud-storage) (1.1.0)
    Requirement already satisfied: google-auth<2.0dev,>=1.11.0 in /opt/conda/lib/python3.7/site-packages (from google-cloud-storage) (1.22.0)
    Requirement already satisfied: google-cloud-core<2.0dev,>=1.2.0 in /opt/conda/lib/python3.7/site-packages (from google-cloud-storage) (1.3.0)
    Requirement already satisfied: google-crc32c<2.0dev,>=1.0; python_version >= "3.5" in /opt/conda/lib/python3.7/site-packages (from google-resumable-media<2.0dev,>=0.6.0->google-cloud-storage) (1.0.0)
    Requirement already satisfied: six in /opt/conda/lib/python3.7/site-packages (from google-resumable-media<2.0dev,>=0.6.0->google-cloud-storage) (1.15.0)
    Requirement already satisfied: pyasn1-modules>=0.2.1 in /opt/conda/lib/python3.7/site-packages (from google-auth<2.0dev,>=1.11.0->google-cloud-storage) (0.2.7)
    Requirement already satisfied: rsa<5,>=3.1.4; python_version >= "3.5" in /opt/conda/lib/python3.7/site-packages (from google-auth<2.0dev,>=1.11.0->google-cloud-storage) (4.6)
    Requirement already satisfied: cachetools<5.0,>=2.0.0 in /opt/conda/lib/python3.7/site-packages (from google-auth<2.0dev,>=1.11.0->google-cloud-storage) (4.1.1)
    Requirement already satisfied: aiohttp<4.0.0dev,>=3.6.2; python_version >= "3.6" in /opt/conda/lib/python3.7/site-packages (from google-auth<2.0dev,>=1.11.0->google-cloud-storage) (3.6.2)
    Requirement already satisfied: setuptools>=40.3.0 in /opt/conda/lib/python3.7/site-packages (from google-auth<2.0dev,>=1.11.0->google-cloud-storage) (49.6.0.post20201009)
    Requirement already satisfied: google-api-core<2.0.0dev,>=1.16.0 in /opt/conda/lib/python3.7/site-packages (from google-cloud-core<2.0dev,>=1.2.0->google-cloud-storage) (1.22.4)
    Requirement already satisfied: cffi>=1.0.0 in /opt/conda/lib/python3.7/site-packages (from google-crc32c<2.0dev,>=1.0; python_version >= "3.5"->google-resumable-media<2.0dev,>=0.6.0->google-cloud-storage) (1.14.3)
    Requirement already satisfied: pyasn1<0.5.0,>=0.4.6 in /opt/conda/lib/python3.7/site-packages (from pyasn1-modules>=0.2.1->google-auth<2.0dev,>=1.11.0->google-cloud-storage) (0.4.8)
    Requirement already satisfied: attrs>=17.3.0 in /opt/conda/lib/python3.7/site-packages (from aiohttp<4.0.0dev,>=3.6.2; python_version >= "3.6"->google-auth<2.0dev,>=1.11.0->google-cloud-storage) (20.2.0)
    Requirement already satisfied: async-timeout<4.0,>=3.0 in /opt/conda/lib/python3.7/site-packages (from aiohttp<4.0.0dev,>=3.6.2; python_version >= "3.6"->google-auth<2.0dev,>=1.11.0->google-cloud-storage) (3.0.1)
    Requirement already satisfied: chardet<4.0,>=2.0 in /opt/conda/lib/python3.7/site-packages (from aiohttp<4.0.0dev,>=3.6.2; python_version >= "3.6"->google-auth<2.0dev,>=1.11.0->google-cloud-storage) (3.0.4)
    Requirement already satisfied: multidict<5.0,>=4.5 in /opt/conda/lib/python3.7/site-packages (from aiohttp<4.0.0dev,>=3.6.2; python_version >= "3.6"->google-auth<2.0dev,>=1.11.0->google-cloud-storage) (4.7.5)
    Requirement already satisfied: yarl<2.0,>=1.0 in /opt/conda/lib/python3.7/site-packages (from aiohttp<4.0.0dev,>=3.6.2; python_version >= "3.6"->google-auth<2.0dev,>=1.11.0->google-cloud-storage) (1.3.0)
    Requirement already satisfied: requests<3.0.0dev,>=2.18.0 in /opt/conda/lib/python3.7/site-packages (from google-api-core<2.0.0dev,>=1.16.0->google-cloud-core<2.0dev,>=1.2.0->google-cloud-storage) (2.24.0)
    Requirement already satisfied: googleapis-common-protos<2.0dev,>=1.6.0 in /opt/conda/lib/python3.7/site-packages (from google-api-core<2.0.0dev,>=1.16.0->google-cloud-core<2.0dev,>=1.2.0->google-cloud-storage) (1.52.0)
    Requirement already satisfied: pytz in /opt/conda/lib/python3.7/site-packages (from google-api-core<2.0.0dev,>=1.16.0->google-cloud-core<2.0dev,>=1.2.0->google-cloud-storage) (2020.1)
    Requirement already satisfied: protobuf>=3.12.0 in /opt/conda/lib/python3.7/site-packages (from google-api-core<2.0.0dev,>=1.16.0->google-cloud-core<2.0dev,>=1.2.0->google-cloud-storage) (3.13.0)
    Requirement already satisfied: pycparser in /opt/conda/lib/python3.7/site-packages (from cffi>=1.0.0->google-crc32c<2.0dev,>=1.0; python_version >= "3.5"->google-resumable-media<2.0dev,>=0.6.0->google-cloud-storage) (2.20)
    Requirement already satisfied: idna>=2.0 in /opt/conda/lib/python3.7/site-packages (from yarl<2.0,>=1.0->aiohttp<4.0.0dev,>=3.6.2; python_version >= "3.6"->google-auth<2.0dev,>=1.11.0->google-cloud-storage) (2.10)
    Requirement already satisfied: urllib3!=1.25.0,!=1.25.1,<1.26,>=1.21.1 in /opt/conda/lib/python3.7/site-packages (from requests<3.0.0dev,>=2.18.0->google-api-core<2.0.0dev,>=1.16.0->google-cloud-core<2.0dev,>=1.2.0->google-cloud-storage) (1.25.10)
    Requirement already satisfied: certifi>=2017.4.17 in /opt/conda/lib/python3.7/site-packages (from requests<3.0.0dev,>=2.18.0->google-api-core<2.0.0dev,>=1.16.0->google-cloud-core<2.0dev,>=1.2.0->google-cloud-storage) (2020.6.20)
    Note: you may need to restart the kernel to use updated packages.



```python
pip install pandas
```

    Requirement already satisfied: pandas in /opt/conda/lib/python3.7/site-packages (1.1.3)
    Requirement already satisfied: numpy>=1.15.4 in /opt/conda/lib/python3.7/site-packages (from pandas) (1.18.5)
    Requirement already satisfied: python-dateutil>=2.7.3 in /opt/conda/lib/python3.7/site-packages (from pandas) (2.8.1)
    Requirement already satisfied: pytz>=2017.2 in /opt/conda/lib/python3.7/site-packages (from pandas) (2020.1)
    Requirement already satisfied: six>=1.5 in /opt/conda/lib/python3.7/site-packages (from python-dateutil>=2.7.3->pandas) (1.15.0)
    Note: you may need to restart the kernel to use updated packages.



```python
pip install plotly==4.12.0
```

    Collecting plotly==4.12.0
      Downloading plotly-4.12.0-py2.py3-none-any.whl (13.1 MB)
    [K     |████████████████████████████████| 13.1 MB 4.5 MB/s eta 0:00:01
    [?25hRequirement already satisfied: retrying>=1.3.3 in /opt/conda/lib/python3.7/site-packages (from plotly==4.12.0) (1.3.3)
    Requirement already satisfied: six in /opt/conda/lib/python3.7/site-packages (from plotly==4.12.0) (1.15.0)
    Installing collected packages: plotly
    Successfully installed plotly-4.12.0
    Note: you may need to restart the kernel to use updated packages.



```python
pip install anvil-uplink
```

    Requirement already satisfied: anvil-uplink in /opt/conda/lib/python3.7/site-packages (0.3.34)
    Requirement already satisfied: ws4py in /opt/conda/lib/python3.7/site-packages (from anvil-uplink) (0.5.1)
    Requirement already satisfied: six in /opt/conda/lib/python3.7/site-packages (from anvil-uplink) (1.15.0)
    Requirement already satisfied: future in /opt/conda/lib/python3.7/site-packages (from anvil-uplink) (0.18.2)
    Requirement already satisfied: argparse in /opt/conda/lib/python3.7/site-packages (from anvil-uplink) (1.4.0)
    Note: you may need to restart the kernel to use updated packages.



```python
@anvil.server.callable
def get_data(a,b):
    graph = total_needs_on_a_given_day(ca_table, a, b)
    print(graph)
    return (graph)
anvil.server.wait_forever()
```


```python
from google.cloud import storage
import pandas as pd
import datetime

staff_ledger = pd.read_csv('gs://data_storage_covid_hackathon/HPAC-COVID-19 - Staff Ledger.csv', sep=",")
staff_ledger

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Role</th>
      <th>Specialty</th>
      <th>Status</th>
      <th>Shift</th>
      <th>Alt. Shift 1</th>
      <th>Alt. Shift 2</th>
      <th>Number</th>
      <th>Alt. Number</th>
      <th>Messaging Number</th>
      <th>...</th>
      <th>Secondary 2</th>
      <th>Secondary 3</th>
      <th>Secondary 4</th>
      <th>Secondary 5</th>
      <th>Secondary 6</th>
      <th>Secondary 7</th>
      <th>Secondary 8</th>
      <th>Secondary 9</th>
      <th>Secondary 10</th>
      <th>Secondary 11</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>CA 1</td>
      <td>CA I</td>
      <td>CA I</td>
      <td>PRN</td>
      <td>A</td>
      <td>D</td>
      <td>NaN</td>
      <td>52-367-362</td>
      <td>NaN</td>
      <td>52367362@messaging.sprinpcs.com</td>
      <td>...</td>
      <td>Hospital 3</td>
      <td>Hospital 2</td>
      <td>Hospital 7</td>
      <td>Hospital 1</td>
      <td>Hospital 8</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>CA 4</td>
      <td>CA I</td>
      <td>CAI/SHA</td>
      <td>PRN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>52-87-8855</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>Hospital 7</td>
      <td>Hospital 8</td>
      <td>Hospital 9</td>
      <td>Hospital 5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>CA 5</td>
      <td>CA I</td>
      <td>CA I</td>
      <td>PRN</td>
      <td>P</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>52-363-50</td>
      <td>NaN</td>
      <td>5236350@momail.ne</td>
      <td>...</td>
      <td>Hospital 2</td>
      <td>Hospital 7</td>
      <td>Hospital 8</td>
      <td>Hospital 9</td>
      <td>Hospital 3</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>CA 6</td>
      <td>CA I</td>
      <td>CA I</td>
      <td>PRN</td>
      <td>D</td>
      <td>E</td>
      <td>N</td>
      <td>52-566-2244</td>
      <td>NaN</td>
      <td>525662244@momail.ne</td>
      <td>...</td>
      <td>Hospital 2</td>
      <td>Hospital 7</td>
      <td>Hospital 8</td>
      <td>Hospital 9</td>
      <td>Hospital 3</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>CA 7</td>
      <td>CA I</td>
      <td>CA I</td>
      <td>PRN</td>
      <td>P</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>52-363-3684</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>Hospital 2</td>
      <td>Hospital 7</td>
      <td>Hospital 8</td>
      <td>Hospital 9</td>
      <td>Hospital 3</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>243</th>
      <td>CST 3</td>
      <td>Surg Tech</td>
      <td>Surg Tech</td>
      <td>PRN</td>
      <td>D</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>52-876-623</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>244</th>
      <td>CST 4</td>
      <td>Surg Tech</td>
      <td>Surg Tech</td>
      <td>PRN</td>
      <td>D</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>52-632-0477</td>
      <td>NaN</td>
      <td>526320477@mms.a.ne</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>245</th>
      <td>CST 5</td>
      <td>Surg Tech</td>
      <td>Surg Tech</td>
      <td>PRN</td>
      <td>D</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>40-867-370</td>
      <td>NaN</td>
      <td>40867370@VEX.COM</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>246</th>
      <td>CST 6</td>
      <td>Surg Tech</td>
      <td>Surg Tech</td>
      <td>24</td>
      <td>D</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>52-26-70</td>
      <td>NaN</td>
      <td>522670@vex.com</td>
      <td>...</td>
      <td>Hospital 3</td>
      <td>Hospital 2</td>
      <td>Hospital 1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>247</th>
      <td>CST 7</td>
      <td>Surg Tech</td>
      <td>Surg Tech</td>
      <td>PRN</td>
      <td>D</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>52-2-8383</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>248 rows × 30 columns</p>
</div>




```python
icu_micu_sicu_imc_table = pd.read_csv('gs://data_storage_covid_hackathon/HPAC-COVID-19 - ICU.csv', sep=",", header = 1)
icu_micu_sicu_imc_table = icu_micu_sicu_imc_table.rename(columns={"ICU/IMC Needs": "Needs",})
icu_micu_sicu_imc_table = ed_table.rename(columns={"12/1/2019":"Date", "Hospital 1":"Site", "SICU":"Area", "1":"Needs",})

icu_micu_sicu_imc_table
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Site</th>
      <th>Area</th>
      <th>Shift</th>
      <th>Needs</th>
      <th>Float Filled</th>
      <th>Unfilled</th>
      <th>Float Cancelled</th>
      <th>Over</th>
      <th>On-Call</th>
      <th>Unit Filled</th>
      <th></th>
      <th>Staffing to grid?</th>
      <th>Unnamed: 13</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>12/1/2019</td>
      <td>Hospital 1</td>
      <td>ED</td>
      <td>A</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>1 PB</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>12/1/2019</td>
      <td>Hospital 2</td>
      <td>ED</td>
      <td>A</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>12/1/2019</td>
      <td>Hospital 3</td>
      <td>ED</td>
      <td>A</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>12/1/2019</td>
      <td>Hospital 4</td>
      <td>ED</td>
      <td>A</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>12/1/2019</td>
      <td>Hospital 5</td>
      <td>ED</td>
      <td>A</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>2 PB</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>22813</th>
      <td>11/8/2020</td>
      <td>Hospital 9</td>
      <td>ED</td>
      <td>P</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>22814</th>
      <td>11/8/2020</td>
      <td>Hospital 11</td>
      <td>ED</td>
      <td>P</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>22815</th>
      <td>11/8/2020</td>
      <td>Hospital 7</td>
      <td>ED</td>
      <td>P</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>22816</th>
      <td>11/8/2020</td>
      <td>Hospital 12</td>
      <td>ED</td>
      <td>P</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>22817</th>
      <td>11/8/2020</td>
      <td>Float</td>
      <td>ED</td>
      <td>P</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>22818 rows × 14 columns</p>
</div>




```python
ed_table = pd.read_csv('gs://data_storage_covid_hackathon/HPAC-COVID-19 - ED.csv', sep=",")
ed_table = ed_table.rename(columns={"ED Needs": "Needs",})

ed_table
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Site</th>
      <th>Area</th>
      <th>Shift</th>
      <th>Needs</th>
      <th>Float Filled</th>
      <th>Unfilled</th>
      <th>Float Cancelled</th>
      <th>Over</th>
      <th>On-Call</th>
      <th>Unit Filled</th>
      <th></th>
      <th>Staffing to grid?</th>
      <th>Unnamed: 13</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>12/1/2019</td>
      <td>Hospital 1</td>
      <td>ED</td>
      <td>A</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>1 PB</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>12/1/2019</td>
      <td>Hospital 2</td>
      <td>ED</td>
      <td>A</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>12/1/2019</td>
      <td>Hospital 3</td>
      <td>ED</td>
      <td>A</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>12/1/2019</td>
      <td>Hospital 4</td>
      <td>ED</td>
      <td>A</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>12/1/2019</td>
      <td>Hospital 5</td>
      <td>ED</td>
      <td>A</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>2 PB</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>22813</th>
      <td>11/8/2020</td>
      <td>Hospital 9</td>
      <td>ED</td>
      <td>P</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>22814</th>
      <td>11/8/2020</td>
      <td>Hospital 11</td>
      <td>ED</td>
      <td>P</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>22815</th>
      <td>11/8/2020</td>
      <td>Hospital 7</td>
      <td>ED</td>
      <td>P</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>22816</th>
      <td>11/8/2020</td>
      <td>Hospital 12</td>
      <td>ED</td>
      <td>P</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>22817</th>
      <td>11/8/2020</td>
      <td>Float</td>
      <td>ED</td>
      <td>P</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>22818 rows × 14 columns</p>
</div>




```python
psa_table = pd.read_csv('gs://data_storage_covid_hackathon/HPAC-COVID-19 - PSA.csv', sep=",")
psa_table = psa_table.rename(columns={"PSA Needs": "Needs",})

psa_table
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Site</th>
      <th>Area</th>
      <th>Shift</th>
      <th>Needs</th>
      <th>Float Filled</th>
      <th>Unfilled</th>
      <th>Float Cancelled</th>
      <th>Over</th>
      <th>Unit Filled</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>10/26/2020</td>
      <td>Hospital 1</td>
      <td>PSA</td>
      <td>A</td>
      <td>4</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>10/26/2020</td>
      <td>Hospital 2</td>
      <td>PSA</td>
      <td>A</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>10/26/2020</td>
      <td>Hospital 3</td>
      <td>PSA</td>
      <td>A</td>
      <td>1</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>10/26/2020</td>
      <td>Hospital 4</td>
      <td>PSA</td>
      <td>A</td>
      <td>3</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>10/26/2020</td>
      <td>Hospital 5</td>
      <td>PSA</td>
      <td>A</td>
      <td>3</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1021</th>
      <td>2020</td>
      <td>Float</td>
      <td>PSA</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1022</th>
      <td>2020</td>
      <td>Float</td>
      <td>PSA</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1023</th>
      <td>2020</td>
      <td>Float</td>
      <td>PSA</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1024</th>
      <td>2020</td>
      <td>Float</td>
      <td>PSA</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1025</th>
      <td>2020</td>
      <td>Float</td>
      <td>PSA</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>1026 rows × 10 columns</p>
</div>




```python
ca_table = pd.read_csv('gs://data_storage_covid_hackathon/HPAC-COVID-19 - CA.csv', sep=",")
ca_table = ca_table.rename(columns={"Area": "Site",})
ca_table = ca_table.rename(columns={"CA Needs": "Needs",})

future_time_expander = 365

#while future_time_expander > 0:
   # future_time = {"Date":datetime.date.today().year, "Site":"Float", "Area":"CA", "Shift":0, "Needs":0}
   # ca_table = ca_table.append(future_time, ignore_index=True)
   # future_time_expander = future_time_expander - 1

ca_table
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Site</th>
      <th>Shift</th>
      <th>Needs</th>
      <th>Float Filled</th>
      <th>Unfilled</th>
      <th>Float Cancelled</th>
      <th>Over</th>
      <th>On-Call</th>
      <th>Unit Filled</th>
      <th>Support staff requested</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>10/26/2020</td>
      <td>Hospital 1</td>
      <td>A</td>
      <td>3</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>10/26/2020</td>
      <td>Hospital 2</td>
      <td>A</td>
      <td>5</td>
      <td>0</td>
      <td>5</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>10/26/2020</td>
      <td>Hospital 3</td>
      <td>A</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>10/26/2020</td>
      <td>Hospital 4</td>
      <td>A</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>10/26/2020</td>
      <td>Hospital 5</td>
      <td>A</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>665</th>
      <td>11/6/2020</td>
      <td>Hospital 5</td>
      <td>N</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>666</th>
      <td>11/6/2020</td>
      <td>Hospital 7</td>
      <td>N</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>667</th>
      <td>11/6/2020</td>
      <td>Hospital 8</td>
      <td>N</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>668</th>
      <td>11/6/2020</td>
      <td>Hospital 9</td>
      <td>N</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>669</th>
      <td>11/6/2020</td>
      <td>Float</td>
      <td>N</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>670 rows × 11 columns</p>
</div>




```python
import anvil.server
anvil.server.connect("CNIA54ONSSQOKRHY7BXY3GFR-QBM43D5SUB5SYH7B")
import plotly.graph_objects as graph
import numpy as np
import math
from sklearn.linear_model import LinearRegression

def determine_day_of_the_year(month_day_year):
    
    #divides the string into managable chuncks
    month_day_year = month_day_year.split("/")
    month = int(month_day_year[0])
    day = int(month_day_year[1])
    year = int(month_day_year[2])
    
    #Is the year a leap year? The code could be inmproved to account for centuries in the year subtraction, but our data doesn't go back that far.
    if (((year % 4) == 0 and (year % 100) != 0) or (year % 400) == 0):
        days_per_month = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    else:
        days_per_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        
    sum_of_days = 0
    month_index = month - 1
 
    while month_index > 0:
        sum_of_days = sum_of_days + days_per_month[month_index]
        month_index = month_index - 1
    
    sum_of_days = sum_of_days + day
    
    return sum_of_days

def week_shift(month_day_year, day_indexer):
    
    #divides the string into managable chuncks
    month_day_year = month_day_year.split("/")
    month = int(month_day_year[0])
    day = int(month_day_year[1])
    year = int(month_day_year[2])
    
    #Is the year a leap year? The code could be inmproved to account for centuries in the year subtraction, but our data doesn't go back that far.
    if (((year % 4) == 0 and (year % 100) != 0) or (year % 400) == 0):
        days_per_month = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    else:
        days_per_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

    day_index = day_indexer

    while day_index > 0:
        if month == 1 and day == 1:
            month = 12
            day = 31
            year = year - 1
        elif day == 1:
            if days_per_month[month - 1] == 30:
                day = 30
            elif days_per_month[month - 1] == 31:
                day = 31
            elif days_per_month[month - 1] == 28:
                day = 28
            else:
                day = 29
            month = month - 1
        else:
            day = day - 1
            
        day_index = day_index - 1
    
    month_day_year = str(month) + "/" + str(day) + "/" + str(year)
    
    return month_day_year
    
def find_index_of_year(table, month_day_year, index_table):

    #This loop goes through the table until it finds the date 
    while index_table > 0:
        if month_day_year == table.loc[index_table, "Date"]:
            break
        index_table = index_table - 1
        
    return index_table
    
def total_needs_on_a_given_day(table, hospital_number, shift, day_of_the_year, number_of_days):
    
    hospital_shift = shift
    
    #I am assigning numbers to the days in order to determine which index I should begin at in the table. It is necessary to find the differnce in days.
    day_prediction_shifted = day_of_the_year
    last_day_on_record = table.loc[len(table) - 1, "Date"]
    
    day_total_1 = determine_day_of_the_year(day_prediction_shifted)
    day_total_2 = determine_day_of_the_year(last_day_on_record)
    
    if day_total_1 > day_total_2:
        day_total = day_total_1 - day_total_2
    else:
        day_total = 365 - day_total_2 + day_total_1
    
    #The purpose of this code is to bring the day that we are trying to predict within 7 days of the last day in the records.
    #Without this, the extrapolation breaks.
    
    day_prediction_shifted = week_shift(day_prediction_shifted, day_total - day_total % 7 )

    
    day_prediction_shifted = week_shift(day_prediction_shifted, 7)

    #These arrays act as bins to dump information into for graphing purposes. They are also used for the linear regression.
    date_array = np.array([])
    y_graphing_data = np.array([])
    x_graphing_data = np.array([])
    
    x_values = 1
    array_size = number_of_days
    while array_size > 0:
        y_graphing_data = np.append(y_graphing_data, 0)
        x_graphing_data = np.append(x_graphing_data, x_values)
        x_values = x_values + 1
        array_size = array_size - 1
    #These arrays store information for the linear regression after the graph.
    linear_regression_x = np.array([])
    linear_regression_y = np.array([])

    #These indeces are used by the while loop to to run properly.
    #The index counter and number of days counter are controlling how many times the while loop iterates.
    #counter_1 is used to loop through dates that appear more than once. Without it, the while loop never stops.
    #counter_2 is a value set by the index counter before the loop is processes. It should not change, but every
    #time that counter_1 increases, the difference between counter_2 and counter_1 decrease. This is necessary to drive the loop forward.
    #counter_3 controls which array index the needs data is dropped into based on the date.
    #x_value_counter is used to creat values for the linear regression.
    index_table = len(table) - 1
    index_table = find_index_of_year(table, day_prediction_shifted, index_table)
    counter_1 = 0
    counter_2 = index_table
    counter_3 = 0

    #This while loop does the heavy lifting by correctly dumping all of the necessary values into their respective bins.
    while index_table > 0:
        
        date = table.loc[counter_2 - counter_1, "Date"]
        shift = table.loc[counter_2 - counter_1, "Shift"]
        date = str(date)

        if (hospital_number == table.loc[counter_2-counter_1, "Site"] or hospital_number == "All" or hospital_number == "Float") and (hospital_shift == shift or hospital_shift == "All"):
            
            #This code places the needs data into the correct bin for graphing and extrapolating later
            y_graphing_data[counter_3] = y_graphing_data[counter_3] + int(table.loc[counter_2 - counter_1, "Needs"]) 

        counter_1 = counter_1 + 1

        if date != table.loc[counter_2 - counter_1, "Date"]:
            day_prediction_shifted = week_shift(day_prediction_shifted, 7) 
            temp_index = index_table
            index_table = find_index_of_year(table, day_prediction_shifted, index_table)
            
            
            while index_table == 0:
                day_prediction_shifted = week_shift(day_prediction_shifted, 14)
                index_table = temp_index
                index_table = find_index_of_year(table, day_prediction_shifted, index_table)
                if index_table > 0:
                    break
                    
            counter_1 = 0
            counter_2 = index_table
            
            date_array = np.append(date_array, date)
            
            counter_3 = counter_3 + 1

            if counter_3 == number_of_days:
                break
    
    #Most of the data come out of the function backwards, so it is reversed here.
    y_graphing_data = np.flip(y_graphing_data)
    date_array = np.flip(date_array)
    date_array = np.append(date_array, "Predicted Value")
    
     #This code runs a linear regression on the code in order to predict future data based on past data
    linreg = LinearRegression()
    linear_regression_x = x_graphing_data.reshape(-1, 1)
    linear_regression_y = y_graphing_data
    linreg.fit(linear_regression_x, linear_regression_y)
    staff_needs = linreg.predict(linear_regression_x)
    
    staff_needs_prediction = linreg.coef_ * (x_values + 1) + linreg.intercept_
    staff_needs_prediction = math.ceil(staff_needs_prediction)
    
    y_graphing_data = np.append(y_graphing_data, staff_needs_prediction)
    
    
    
    bar_colors = (["green"]) * (x_values - 1)
    bar_colors = np.append(bar_colors, "orange")

    #The data is plotted with this code
    historical_data = graph.Figure(data=graph.Bar(y = y_graphing_data, x = date_array, marker_color = bar_colors))
    historical_data.update_layout(
        title="Floating Nurses Needed in the Past Week",
        title_x = .5,
        xaxis_title = "Day of the Year",
        yaxis_title = "Amount of People Needed in the Department",
        font = dict(
            family = "Courier New, monospace",
            size = 12,
            color = "seagreen"))
    

    historical_data.show()
    
    print("It is estimated that you need", staff_needs_prediction, "floating nurse(s)")
    

    front_end_data = []
    front_end_data.append(y_graphing_data)
    front_end_data.append(date_array)
    front_end_data.append(staff_needs_prediction)
    front_end_data.append(bar_colors)
    return (front_end_data)
 
 
@anvil.server.callable
def get_data(table_string, hospital_numb, shift, prediction_date, leading_days):
    if (table_string == "ICU Needs"):
        table = icu_table
    elif (table_string == "ED Needs"):
        table = ed_table
    elif (table_string == "PSA Needs"):
        table = psa_table
    elif (table_string == "CA Needs"):
        table = ca_table
  
    graph = total_needs_on_a_given_day(table, hospital_numb, shift, prediction_date, leading_days)
    print(graph)
    return (graph)
anvil.server.wait_forever()

```


<div>                            <div id="d501387f-3444-4bfd-b3f6-5fe0c073f610" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("d501387f-3444-4bfd-b3f6-5fe0c073f610")) {                    Plotly.newPlot(                        "d501387f-3444-4bfd-b3f6-5fe0c073f610",                        [{"marker": {"color": ["green", "green", "green", "green", "green", "green", "green", "green", "green", "green", "orange"]}, "type": "bar", "x": ["9/4/2020", "9/11/2020", "9/18/2020", "9/25/2020", "10/1/2020", "10/8/2020", "10/15/2020", "10/22/2020", "10/29/2020", "11/6/2020", "Predicted Value"], "y": [8.0, 1.0, 7.0, 6.0, 4.0, 2.0, 3.0, 1.0, 1.0, 7.0, 3.0]}],                        {"font": {"color": "seagreen", "family": "Courier New, monospace", "size": 12}, "template": {"data": {"bar": [{"error_x": {"color": "#2a3f5f"}, "error_y": {"color": "#2a3f5f"}, "marker": {"line": {"color": "#E5ECF6", "width": 0.5}}, "type": "bar"}], "barpolar": [{"marker": {"line": {"color": "#E5ECF6", "width": 0.5}}, "type": "barpolar"}], "carpet": [{"aaxis": {"endlinecolor": "#2a3f5f", "gridcolor": "white", "linecolor": "white", "minorgridcolor": "white", "startlinecolor": "#2a3f5f"}, "baxis": {"endlinecolor": "#2a3f5f", "gridcolor": "white", "linecolor": "white", "minorgridcolor": "white", "startlinecolor": "#2a3f5f"}, "type": "carpet"}], "choropleth": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "type": "choropleth"}], "contour": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "contour"}], "contourcarpet": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "type": "contourcarpet"}], "heatmap": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "heatmap"}], "heatmapgl": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "heatmapgl"}], "histogram": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "histogram"}], "histogram2d": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "histogram2d"}], "histogram2dcontour": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "histogram2dcontour"}], "mesh3d": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "type": "mesh3d"}], "parcoords": [{"line": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "parcoords"}], "pie": [{"automargin": true, "type": "pie"}], "scatter": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatter"}], "scatter3d": [{"line": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatter3d"}], "scattercarpet": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattercarpet"}], "scattergeo": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattergeo"}], "scattergl": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattergl"}], "scattermapbox": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattermapbox"}], "scatterpolar": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatterpolar"}], "scatterpolargl": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatterpolargl"}], "scatterternary": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatterternary"}], "surface": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "surface"}], "table": [{"cells": {"fill": {"color": "#EBF0F8"}, "line": {"color": "white"}}, "header": {"fill": {"color": "#C8D4E3"}, "line": {"color": "white"}}, "type": "table"}]}, "layout": {"annotationdefaults": {"arrowcolor": "#2a3f5f", "arrowhead": 0, "arrowwidth": 1}, "coloraxis": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "colorscale": {"diverging": [[0, "#8e0152"], [0.1, "#c51b7d"], [0.2, "#de77ae"], [0.3, "#f1b6da"], [0.4, "#fde0ef"], [0.5, "#f7f7f7"], [0.6, "#e6f5d0"], [0.7, "#b8e186"], [0.8, "#7fbc41"], [0.9, "#4d9221"], [1, "#276419"]], "sequential": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "sequentialminus": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]]}, "colorway": ["#636efa", "#EF553B", "#00cc96", "#ab63fa", "#FFA15A", "#19d3f3", "#FF6692", "#B6E880", "#FF97FF", "#FECB52"], "font": {"color": "#2a3f5f"}, "geo": {"bgcolor": "white", "lakecolor": "white", "landcolor": "#E5ECF6", "showlakes": true, "showland": true, "subunitcolor": "white"}, "hoverlabel": {"align": "left"}, "hovermode": "closest", "mapbox": {"style": "light"}, "paper_bgcolor": "white", "plot_bgcolor": "#E5ECF6", "polar": {"angularaxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}, "bgcolor": "#E5ECF6", "radialaxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}}, "scene": {"xaxis": {"backgroundcolor": "#E5ECF6", "gridcolor": "white", "gridwidth": 2, "linecolor": "white", "showbackground": true, "ticks": "", "zerolinecolor": "white"}, "yaxis": {"backgroundcolor": "#E5ECF6", "gridcolor": "white", "gridwidth": 2, "linecolor": "white", "showbackground": true, "ticks": "", "zerolinecolor": "white"}, "zaxis": {"backgroundcolor": "#E5ECF6", "gridcolor": "white", "gridwidth": 2, "linecolor": "white", "showbackground": true, "ticks": "", "zerolinecolor": "white"}}, "shapedefaults": {"line": {"color": "#2a3f5f"}}, "ternary": {"aaxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}, "baxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}, "bgcolor": "#E5ECF6", "caxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}}, "title": {"x": 0.05}, "xaxis": {"automargin": true, "gridcolor": "white", "linecolor": "white", "ticks": "", "title": {"standoff": 15}, "zerolinecolor": "white", "zerolinewidth": 2}, "yaxis": {"automargin": true, "gridcolor": "white", "linecolor": "white", "ticks": "", "title": {"standoff": 15}, "zerolinecolor": "white", "zerolinewidth": 2}}}, "title": {"text": "Floating Nurses Needed in the Past Week", "x": 0.5}, "xaxis": {"title": {"text": "Day of the Year"}}, "yaxis": {"title": {"text": "Amount of People Needed in the Department"}}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('d501387f-3444-4bfd-b3f6-5fe0c073f610');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>


    It is estimated that you need 3 floating nurse(s)
    [array([8., 1., 7., 6., 4., 2., 3., 1., 1., 7., 3.]), array(['9/4/2020', '9/11/2020', '9/18/2020', '9/25/2020', '10/1/2020',
           '10/8/2020', '10/15/2020', '10/22/2020', '10/29/2020', '11/6/2020',
           'Predicted Value'], dtype='<U32'), 3, array(['green', 'green', 'green', 'green', 'green', 'green', 'green',
           'green', 'green', 'green', 'orange'], dtype='<U6')]



```python

```
